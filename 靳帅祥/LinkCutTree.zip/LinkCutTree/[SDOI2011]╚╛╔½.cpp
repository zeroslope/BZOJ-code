/****************************************\
* Author : hzoi_ztx
* Title  : bzoj 2243: [SDOI2011]Ⱦɫ
* ALG    : LCT
* CMT    : 
* Data   : 
\****************************************/

#include <cstdio>

int CH ;
inline void read(int& ret) {
    ret = 0 ; while (CH=getchar() , CH<'!') ;
    while (ret = ret*10+CH-'0' , CH=getchar() , CH>'!') ;
}

#define  maxn  100010LL
#define  maxe  200010LL

int fa[maxn] = {0} , ch[maxn][2] = {0} ;
int cov[maxn] = {0} ;
int c[maxn] = {0} , lc[maxn] = {0} , rc[maxn] = {0} , d[maxn] = {0} ; 

#define  null      0LL
#define  left(u)   ch[u][0]
#define  right(u)  ch[u][1]

inline bool root(int u){ return ((!fa[u])||(fa[u]&&(left(fa[u])!=u)&&(right(fa[u])!=u))) ; }
inline void Maintain(int u) {
    lc[u] = left(u) ? lc[left(u)] : c[u] ;
    rc[u] = right(u) ? rc[right(u)] : c[u] ;
    d[u] = d[left(u)]+1+d[right(u)]-(rc[left(u)]==c[u])-(lc[right(u)]==c[u]) ;
}

inline void Change(int u , int w) {
    if (!u) return ;
    lc[u] = rc[u] = c[u] = cov[u] = w ; d[u] = 1 ;
}

inline void Spread(int u) {
	if (!u) return ;
    if (cov[u]) {
        Change(left(u) , cov[u]) ;
        Change(right(u) , cov[u]) ;
        cov[u] = 0 ;
    }
}

inline void Clear(int u) {
    if (!root(u)) Clear(fa[u]) ;
    Spread(u) ;
}

inline void zig(int x) {
	/* right rotate */
    int y = fa[x] , z = fa[y] ;
    if (left(z) == y) left(z) = x ; else if(right(z) == y) right(z) = x ; fa[x] = z ;
    fa[right(x)] = y ; left(y) = right(x) ; fa[y] = x ; right(x) = y ;
    Maintain(y) ;
}

inline void zag(int x) {
	/* left rotate */
    int y = fa[x] , z = fa[y] ;
    if (left(z) == y) left(z) = x ; else if(right(z) == y) right(z) = x ; fa[x] = z ;
    fa[left(x)] = y ; right(y) = left(x) ; fa[y] = x ; left(x) = y ;
    Maintain(y) ;
}
 
inline void Splay(int x) {
    Clear(x) ;
    for (int y , z ; !root(x) ; ) {
        y = fa[x] , z = fa[y] ;
        if (root(y))
            if(left(y) == x) zig(x) ; else zag(x) ;
        else if(left(z) == y)
            if(left(y) == x) zig(y),zig(x) ; else zag(x),zig(x) ;
        else if(right(y) == x) zag(y),zag(x) ; else zig(x),zag(x) ;
    }
    Maintain(x) ;
}

inline void QUERY(int u , int v) {
	for (int z = null ; v ; v = fa[v] ) {
		Splay(v) ; right(v) = z , z = v ; Maintain(v) ;
	}
	for (v = null ; u ; u = fa[u]) {
    	Splay(u) ;
    	if (!fa[u]) {
			printf("%d\n", d[right(u)]+d[v]+1-(c[u]==lc[right(u)])-(c[u]==lc[v]) ) ;
            return ;
		}
		right(u) = v , v = u ; Maintain(u) ;
	}
}

inline void CHANGE(int u , int v , int w) {
	for (int z = null ; v ; v = fa[v] ) {
		Splay(v) ; right(v) = z , z = v ; Maintain(v) ;
	}
    for (v = null ; u ; u = fa[u]) {
    	Splay(u) ;
    	if (!fa[u]) {
    		c[u] = w ;
    		Change(right(u) , w) ;
    		Change(v , w) ;
		}
		right(u) = v , v = u ; Maintain(u) ;
	}
}

struct FST { int to , next ; } e[maxe] ;
int star[maxn] = {0} , tote = 0 ;

inline void AddEdge(int u , int v) {
    e[++tote].to = v ; e[tote].next = star[u] ; star[u] = tote ;
    e[++tote].to = u ; e[tote].next = star[v] ; star[v] = tote ;
}

inline void BuildTree(int fat , int u) {
    fa[u] = fat ; int p , v ;
    for (p = star[u] ; p ; p = e[p].next ) {
        v = e[p].to ; if (v == fat) continue ;
        BuildTree(u , e[p].to) ;
    }
}

int n , q , i , u , v , w ;

int main() {
    #define READ
    #ifdef  READ
        freopen("bzoj_2243.in" ,"r",stdin ) ;
        freopen("bzoj_2243.out","w",stdout) ;
    #endif
    
    read(n) , read(q) ;
    for (i = 1 ; i <= n ; i ++ ) {
        read(c[i]) ; lc[i] = rc[i] = c[i] ; d[i] = 1 ;
    }

    for (i = 1 ; i < n ; i ++ ) {
        read(u) , read(v) ; AddEdge(u , v) ;
    }
    
    BuildTree(null , 1) ;
    
    while ( q -- ) {
        while (w=getchar() , w<'!') ;
        read(u) , read(v) ;
        if (w == 'Q') QUERY(u , v) ;
        else read(w) , CHANGE(u , v , w) ;
    }
    
	#ifdef  READ
        fclose(stdin) ; fclose(stdout) ;
    #else
        getchar() ; getchar() ;
    #endif
    return 0 ;
}
