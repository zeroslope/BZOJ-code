/****************************************\
* Author : hzoi_ztx
* Title  : Pro.II
* ALG    : LCT
* CMT    :
* Data   :
\****************************************/

#include <cstdio>
#include <cstring>

#define  maxn  30010LL
#define  maxm  200010LL
#define  null  0LL
#define  infi  0x7f7f7f7fLL

int CH ;
void read(int& ret) {
    ret = 0 ; while (CH=getchar() , CH<'!') ;
    while (ret=ret*10+CH-'0' , CH=getchar() , CH>'!') ;
}

struct node{
    int fa , left , right  ;
    node() { fa = left = right = 0 ; }
} nodes[maxn] ;

int val[maxn] = {0} , maxv[maxn] = {0} , sum[maxn] = {0} ;

#define fa(x)      nodes[x].fa
#define left(x)    nodes[x].left
#define right(x)   nodes[x].right
#define max(a , b) ((a)>(b)?(a):(b))

template<typename T>
inline void exchange(T& a ,T& b) {
    T c = a ; a = b ; b = c ;
}

void maintain(int u) {
    sum[u] = sum[left(u)]+val[u]+sum[right(u)] ;
    maxv[u] = max(max(maxv[left(u)],maxv[right(u)]),val[u]) ;
}

bool is_root(int u) {
    if (fa(u) == null) return true ;
    else if (left(fa(u))==u || right(fa(u))==u) return false ;
    else return true ;
}

void zag(int x) {
    /*left rotate*/
    int y = fa(x) ;
    int z = fa(y) ;
    if (left(z) == y) left(z) = x ;
    else if (right(z)==y) right(z) = x ;
         right(y) = left(x) , left(x) = y ;
    fa(right(y)) = y , fa(x) = z , fa(y) = x ;
    maintain(y) ; maintain(x) ;
}

void zig(int x) {
    /*right rotate*/
    int y = fa(x) ;
    int z = fa(y) ;
    if (left(z) == y) left(z) = x ;
    else if (right(z) == y) right(z) = x ;
         left(y) = right(x) , right(x) = y ;
    fa(left(y)) = y , fa(x) = z , fa(y) = x ;
    maintain(y) ; maintain(x) ;
}

void splay(int x) {
    int y , z ;
    while (!is_root(x)) {
        y = fa(x) , z = fa(y) ;
        if (is_root(y)) {
            if (left(y) == x) zig(x) ; else zag(x) ;
        } else if (left(z) == y) {
            if (left(y) == x) zig(y) ; else zag(x) ;
            zig(x) ;
        } else {
            if (right(y) == x) zag(y) ; else zig(x) ;
            zag(x) ;
        }
    }
//    maintain(x) ;
}

void access(int u) {
//printf("\nAcessint :\n") ;
    int v = null ;
    while (u != null) {
        splay(u) , right(u) = v , maintain(u) ;
        v = u , u = fa(u) ;
    }
}

void makeroot(int u) {
//printf("\nmaking root %d:\n",u);
    access(u) , rev(u) ^= true , splay(u) ;
}

int n , m , u , v , i , cmd ;

void change() {
    splay(u) , S[u] = v ;
}

int query() {
//printf("\nQuerying :\n") ;
    makeroot(u) ;
    access(v) , splay(u) ;
    return size(v) ;
}

struct FST{ int to , next ; } e[maxn<<1] ;
int star[maxn] = {0} , tote = 0 ;

void AddEdge() {
    e[++tote].to = v ; e[tote].next = star[u] ; star[u] = tote ;
    e[++tote].to = u ; e[tote].next = star[v] ; star[v] = tote ;
}

void maketree(int u , int par) {
    fa(u) = par ;
    for (int p = star[u] ; p ; p = e[p].next) {
        if (e[p].to != par) maketree(e[p].to , u) ;
    }
}

int main() {
//  #define READ
    #ifdef  READ
        freopen(".in" ,"r",stdin ) ;
        freopen(".out","w",stdout) ;
    #endif
    
    memset(mins , 0x7f , sizeof (mins)) ;
    memset(S , 0x7f , sizeof (S)) ;

    read(n) ;
    for (i = 1 ; i < n ; i ++ ) {
        read(u) , read(v) ; AddEdge() ;   
    }
    
    maketree(1 , null) ;
    
    read(m) ;
    
    while ( m -- ) {
        cmd = getchar() + getchar() ;
        read(u) , read(u) , read(v) ;
        if (cmd == 'Q'+'M') {
        } else if (cmd == 'Q'+'S') {
        } else {
        }
    }
    #ifdef  READ
        fclose(stdin) ; fclose(stdout) ;
    #else
        getchar() ; getchar() ;
    #endif
    return 0 ;
}
