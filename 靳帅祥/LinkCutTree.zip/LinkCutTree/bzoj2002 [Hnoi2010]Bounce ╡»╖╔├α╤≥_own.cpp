/****************************************\
* Author : hzoi_ztx
* Title  : bzoj 2002: [Hnoi2010]Bounce ��������
* ALG    : LCT
* CMT    :
* Data   :
\****************************************/

#include <cstdio>

#define  maxn  200010LL
#define  null  0LL

int CH ;
void read(int& ret) {
     ret = 0 ; while (CH=getchar() , CH<'!') ;
     while (ret=ret*10+CH-'0' , CH=getchar() , CH>'!') ;
}

struct node{
    int fa , left , right , size ;
    /*father , left_son , right_son , subtree_size*/
} nodes[maxn] ;

#define fa(x)      nodes[x].fa
#define left(x)    nodes[x].left
#define right(x)   nodes[x].right
#define size(x)    nodes[x].size
#define min(a , b) (a)<(b)?(a):(b)

void maintain(int u) {
    size(u) = size(left(u))+size(right(u))+1 ;
    /*�� u �ڵ�ά�� size ��*/
}

bool is_root(int u) {
    if (fa(u) == null) return true ;
    else if (left(fa(u))==u || right(fa(u))==u) return false ;
    else return true ;
    /*�жϵ�ǰ�ڵ��Ƿ�Ϊ�������ĸ��ڵ�*/
}

void zag(int x) {
    int y = fa(x) ;
    int z = fa(y) ;
    if (left(z) == y) left(z) = x ;
    else if (right(z)==y) right(z) = x ;
         right(y) = left(x) , left(x) = y ;
    fa(right(y)) = y , fa(x) = z , fa(y) = x ;
    maintain(y) ;
}

void zig(int x) {
    int y = fa(x) ;
    int z = fa(y) ;
    if (left(z) == y) left(z) = x ;
    else if (right(z) == y) right(z) = x ;
         left(y) = right(x) , right(x) = y ;
    fa(left(y)) = y , fa(x) = z , fa(y) = x ;
    maintain(y) ;
}

void splay(int x) {
    int y , z ;
    while (!is_root(x)) {
        y = fa(x) , z = fa(y) ;
        if (is_root(y)) {
            if (left(y) == x) zig(x) ; else zag(x) ;
        } else if (left(z) == y) {
            if (left(y) == x) zig(y) ; else zag(x) ;
            zig(x) ;
        } else {
            if (right(y) == x) zag(y) ; else zig(x) ;
            zag(x) ;
        }
    }
    maintain(x) ;
}

void access(int u) {
    int v = null ;
    while (u != null) {
        splay(u) ;
        right(u) = v , maintain(u) ;
        v = u , u = fa(u) ;
    }
}

void cut(int u , int v) {
    access(u) ; splay(v) ; fa(v) = null ;
}

void link(int u , int v) {
    access(u) ; splay(u) ;
    right(u) = v ; fa(v) = u ;
    maintain(u) ;
}

int query(int u) {
    access(u) ; splay(u) ;
    return size(u)-1 ;
}

int n , m , i , j , k , cmd ;
int K[maxn] ;

int main() {
//	#define READ
	#ifdef  READ
		freopen(".in" ,"r",stdin ) ;
		freopen(".out","w",stdout) ;
	#endif
	read(n) ;
	for (i = 1 ; i <= n ; i ++ ) read(K[i]) ;
	int root = n+1 ;
	for (i = 1 ; i <= n+1 ; i ++ ) size(i) = 1 ;
	for (i = n ; i > 0 ; i -- ) {
        int next = i+K[i] ;
        next = min(next , root) ;
        link(next , i) ;
    }
    read(m) ;
	for (i = 1 ; i <= m ; i ++ ) {
		read(cmd) ;
		if (cmd == 1) {
            read(j) , j ++ ;
			printf("%d\n", query(j) ) ;
		} else {
            read(j) , read(k) , j ++ ;
			int old_next = min(K[j]+j , n+1) ;
			int next = min(k+j , n+1) ;
			cut(old_next , j) ;
			link(next , j) ;
			K[j]=k;
		}
	}
	#ifdef  READ
		fclose(stdin) ; fclose(stdout) ;
	#else
		getchar() ; getchar() ;
	#endif
	return 0 ;
}
