/****************************************\
* Author : hzoi_ztx
* Title  : cogs 1688. [ZJOI2008]����ͳ��Count
* ALG    : LCT
* CMT    : 
* Data   : 
\****************************************/

#include <cstdio>
#include <cstring>

#define  max(a,b)  ((a)>(b)?(a):(b))
#define  infi  0x7f7f7f7fLL

int CH ;
inline void read(int& ret) {
    ret = 0 ; while (CH=getchar() , CH<'!') ;
    if (CH == '-') CH=getchar() , ret = '0'-CH ;
    else ret = CH-'0' ;
    while (CH=getchar() , CH>'!') ret = ret*10+CH-'0' ;
}

#define  maxn  300010LL
#define  maxe  600010LL

bool isrt[maxn] = {0} ;
int ch[maxn][2] = {0} ;
int fa[maxn] = {0} ;
int rev[maxn] = {0} ;
int maxv[maxn] ;
int sumv[maxn] = {0} ;
int val[maxn] = {0} ;

#define  null      0
#define  left(u)   ch[u][0]
#define  right(u)  ch[u][1]

template<typename T>inline void exchange(T&a , T&b) { T c=a;a=b;b=c; }

inline void P(){
       putchar('\n') ;
for (int i = 1 ; i <= 5 ; i ++ ) {
    printf("%d:  fa = %d   ,lc = %d   ,rc = %d   ,maxv = %d   ,sumv = %d   ,rev = %d\n",
    i,fa[i],left(i),right(i),maxv[i] , sumv[i] , rev[i] ) ;
}
printf("\n") ;
}

inline void Maintain(int u) {
    maxv[u] = sumv[u] = val[u] ;
    if (left(u)) maxv[u] = max(maxv[u] , maxv[left(u)]) , sumv[u] += sumv[left(u)] ;
    if (right(u)) maxv[u] = max(maxv[u] , maxv[right(u)]) , sumv[u] += sumv[right(u)] ;
}

inline void Clr(int u) {
    if (u == null) return ;
    if (rev[u]) {
        if (left(u)) rev[left(u)] ^= true ;
        if (right(u)) rev[right(u)] ^= true ;
//printf(": Exc %d 's lc %d rc %d\n",u,left(u),right(u)) ;
        exchange(left(u) , right(u)) ;
//printf(": Now : %d %d\n",left(u),right(u)) ;
        rev[u]  = false ;
    }
}

inline void Sc(int x , int y , bool f) { ch[y][f] = x , fa[x] = y ; }
inline void Rotate(int x , bool f) {
    int y = fa[x] ; Sc(ch[x][f] , y , !f) ;
    fa[x] = fa[fa[x]] ; Sc(y , x , f) ;
    if (isrt[y]) isrt[y] = false , isrt[x] = true ;
    else ch[fa[x]][ch[fa[x]][1]==y] = x ;
    Maintain(y) ;
}

inline void Splay(int x) {
    Clr(x) ;
    int y = fa[x] , z = fa[y] ;
    while (!isrt[x]) {
        if (isrt[y]) {
//printf("Is Root %d\n",y) ;
            Clr(y) , Clr(x) ;
            Rotate(x , left(y)==x) ;  break ;
        }
        Clr(z) , Clr(y) , Clr(x) ;
        bool f = (right(z)==y) ;
        if (ch[y][f] == x) Rotate(y , !f) , Rotate(x , !f) ;
        else Rotate(x , f) , Rotate(x , !f) ;
    }
    Maintain(x) ;
}

inline int Access(int u) {
    int v = null ;
    while (u != null) {
        Splay(u) ; if (right(u)) isrt[right(u)] = true ;
        right(u) = v , Maintain(u) ;
        if (fa[u]) isrt[u] = false ; v = u , u = fa[u] ;
    }
    return v ;
}

inline void MakeRoot(int u) {
/*int TT = Access(u) ;
printf("After Access:%d\n",TT) ;*/
    rev[Access(u)]  ^= true , Splay(u) ;
}

inline void QMAX(int u , int v) {
    if (u == v) { printf("%d\n", val[u] ) ; return ; }
    MakeRoot(u) ; Access(v) , Splay(v) ;
    printf("%d\n", maxv[v] ) ;
}

inline void QSUM(int u , int v) {
    if (u == v) { printf("%d\n", val[u]) ; return ;}
    MakeRoot(u) ; Access(v) , Splay(v) ;
    printf("%d\n", sumv[v] ) ;
}

inline void CHANGE(int u , int v) {
    Splay(u) ; val[u] = v ; Maintain(u) ;
}

struct FST { int to , next ; } e[maxe] ;
int star[maxn] = {0} , tote = 0 ;

inline void AddEdge(int u , int v) {
    e[++tote].to = v ; e[tote].next = star[u] ; star[u] = tote ;
    e[++tote].to = u ; e[tote].next = star[v] ; star[v] = tote ;
}

inline void BuildTree(int fat , int u) {
    fa[u] = fat ; isrt[u] = true ;
    int p , v ;
    for (p = star[u] ; p ; p = e[p].next ) {
        v = e[p].to ; if (v == fat) continue ;
        BuildTree(u , e[p].to) ;
    }
}

int n , q , i , u , v , cmd ;

int main() {
//    #define READ
    #ifdef  READ
        freopen("bzoj_1036.in" ,"r",stdin ) ;
        freopen("bzoj_1036.out","w",stdout) ;
    #endif
    
    read(n) ;
    for (i = 1 ; i < n ; i ++ ) {
        read(u) , read(v) ; AddEdge(u , v) ;
    }

    for (i = 1 ; i <= n ; i ++ )
        read(val[i]) , maxv[i] = sumv[i] = val[i] ;
    BuildTree(null , 1) ;
/*    
MakeRoot(2) ;
P() ;
Access(3) ;
P();
*/

    read(q) ;
//printf("zhiqian : \n") ;
//P() ;
    while ( q -- ) {
        while (CH=getchar() , CH<'!') ;
        while (cmd=CH , CH=getchar() , CH>'!') ;
        read(u) , read(v) ;
        if (cmd == 'X') QMAX(u , v) ;
        if (cmd == 'M') QSUM(u , v) ;
        if (cmd == 'E') CHANGE(u , v) ;
//printf("AfterQuery:") ;
//P() ;
    }

    #ifdef  READ
        fclose(stdin) ; fclose(stdout) ;
    #else
        getchar() ; getchar() ;
    #endif
    return 0 ;
}
/*
5
1 2
1 4
4 3
4 5
1 2 3 4 5
5
QSUM 2 3
QSUM 1 3
QSUM 3 4
QSUM 3 5
QSUM 1 4

4
1 2
2 3
4 1
4 2 1 3
12
QMAX 3 4
QMAX 3 3
QMAX 3 2
QMAX 2 3
QSUM 3 4
QSUM 2 1
CHANGE 1 5
QMAX 3 4
CHANGE 3 6
QMAX 3 4
QMAX 2 4
QSUM 3 4
*/
