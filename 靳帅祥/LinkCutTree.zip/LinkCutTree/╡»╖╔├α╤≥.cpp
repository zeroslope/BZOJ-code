/****************************************\
* Author : hzoi_ztx
* Title  : cogs 1689. [HNOI2010]Bounce ��������
* ALG    : LCT
* CMT    : 
* Data   : 
\****************************************/

#include <cstdio>

#define  min(a,b)  ((a)<(b)?(a):(b))

int CH ;
inline void read(int& ret) {
     ret = 0 ; while (CH=getchar() , CH<'!') ;
     while (ret=ret*10+CH-'0' , CH=getchar() , CH>'!') ;
}

#define  maxn      200010LL
#define  maxm      100000LL

bool isrt[maxn] = {0} ;
int ch[maxn][2] = {0} ;
int fa[maxn] = {0} ;
int size[maxn] = {0} ;

#define  null  0
#define  left(u)   ch[u][0]
#define  right(u)  ch[u][1]

inline void Maintain(int u) { size[u] = size[left(u)]+1+size[right(u)] ; }
inline void Sc(int x , int y , bool f) { ch[y][f] = x , fa[x] = y ; }

inline void Rotate(int x , bool f) {
    int y = fa[x] ; Sc(ch[x][f] , y , !f) ;
    fa[x] = fa[fa[x]] ; Sc(y , x , f) ;
    if (isrt[y]) isrt[y] = false , isrt[x] = true ;
    else ch[fa[x]][ch[fa[x]][1]==y] = x ;
    Maintain(y) ;
}

inline void Splay(int x) {
    while (!isrt[x]) {
        if (isrt[fa[x]]) { Rotate(x , left(fa[x])==x) ;  break ; }
        bool f = (right(fa[fa[x]])==fa[x]) ;
        if (ch[fa[x]][f] == x) Rotate(fa[x] , !f) , Rotate(x , !f) ;
        else Rotate(x , f) , Rotate(x , !f) ;
    }
    Maintain(x) ;
}

inline void Access(int u) {
    int v = null ;
    while (u != null) {
        Splay(u) ; if (right(u)) isrt[right(u)] = true ;
        right(u) = v , Maintain(u) ;
        if (fa[u]) isrt[u] = false ; v = u , u = fa[u] ;
    }
}

int n , m , u , k , cmd ;

#define  root  n+1

inline void query(int u) {
    Access(u) , Splay(root) ;
    printf("%d\n", size[root]-1 ) ;
}

inline void change(int u , int k) {
    Access(u) , Splay(u) ;
    /* after Splay(u) , v is u's left son ,
    because u is deeper than v */
    isrt[left(u)] = true ;
    fa[left(u)] = fa[u] , left(u) = null ;
    Maintain(u) ; fa[u] = min(u+k , root) ;
}

int main() {
    #define READ
    #ifdef  READ
        freopen("bzoj_2002.in" ,"r",stdin ) ;
        freopen("bzoj_2002.out","w",stdout) ;
    #endif
    
    read(n) ;
    for (u = 1 ; u <= n ; u ++ ) {
        read(k) ;
        fa[u] = min(u+k , root) , isrt[u] = true , size[u] = 1 ;
    }
    isrt[root] = true , size[root] = 1 ;
    
    read(m) ;
    
    while ( m -- ) {
        read(cmd) , read(u) , u ++ ;
        if (cmd == 1) query(u) ;
        else read(k) , change(u , k) ;
    }
    #ifdef  READ
        fclose(stdin) ; fclose(stdout) ;
    #else
        getchar() ; getchar() ;
    #endif
    return 0 ;
}
/*
4
1 2 1 1
3
1 1
2 1 1
1 1
*/
